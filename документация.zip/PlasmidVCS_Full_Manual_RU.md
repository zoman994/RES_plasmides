# PlasmidVCS — Полная техническая документация

**Версия 1.0 | Март 2026**
**ФИЦ Биотехнологии РАН, Лаборатория молекулярной биоинженерии**

---

## Часть I. Обзор системы

### 1.1 Что такое PlasmidVCS

PlasmidVCS — система контроля версий для генетических конструктов. Ядро — это git-подобная VCS с семантическим diff на уровне features (не побуквенным), ветвлением вариантов плазмид и трекингом линейджа штаммов. Поверх ядра построен визуальный конструктор (Construct Designer) для сборки конструктов методом drag-and-drop с автоматическим расчётом праймеров.

Три интерфейса к одной базе данных:

- **React Construct Designer** (порт 3000) — визуальная сборка конструктов, расчёт праймеров, экспорт протоколов
- **Streamlit Dashboard** (порт 8501) — просмотр конструктов, diff между версиями, импорт файлов, управление штаммами
- **CLI** (`pvcs`) — все операции из командной строки

### 1.2 Архитектура

```
┌─────────────────┐  ┌─────────────────┐  ┌─────────────┐
│  React Designer  │  │ Streamlit GUI   │  │   CLI pvcs  │
│  (порт 3000)     │  │ (порт 8501)     │  │             │
└────────┬────────┘  └────────┬────────┘  └──────┬──────┘
         │                    │                   │
    ┌────┴────┐               │                   │
    │ FastAPI │               │                   │
    │  (8000) │               │                   │
    └────┬────┘               │                   │
         │                    │                   │
    ┌────┴────────────────────┴───────────────────┴──────┐
    │              src/pvcs/ — ядро системы               │
    │  assembly_engine, overlap, primer design, diff,     │
    │  restriction, golden_gate, kld, parser, models      │
    ├────────────────────────────────────────────────────┤
    │               SQLite база данных                    │
    │  constructs, revisions, features, parts, primers,   │
    │  strains, assemblies, templates, plans              │
    └────────────────────────────────────────────────────┘
```

### 1.3 Файловая структура

```
pvcs/
├── src/pvcs/                  # Ядро (6,378 строк Python, 21 модуль)
│   ├── models.py              # Датаклассы: Feature, Construct, Revision, Primer...
│   ├── database.py            # SQLite CRUD операции
│   ├── assembly_engine.py     # Движок сборки: junction-centric дизайн праймеров
│   ├── overlap.py             # Overlap junction дизайн, binding region selection
│   ├── golden_gate.py         # Golden Gate: overhangs, внутренние сайты, валидация
│   ├── kld.py                 # KLD мутагенез: point mutation, deletion, insertion
│   ├── restriction.py         # RE база данных, find_sites, compatible ends
│   ├── diff.py                # 4-слойный семантический diff
│   ├── parser.py              # GenBank/FASTA парсинг, feature type inference
│   ├── cli.py                 # Click CLI команды
│   ├── utils.py               # calc_tm, reverse_complement, gc_content
│   ├── feature_db.py          # База known features для автоаннотации
│   ├── export.py              # Экспорт GenBank, YAML, HTML
│   ├── parts.py               # Управление библиотекой частей
│   ├── primers.py             # Реестр праймеров, поиск дубликатов
│   ├── strains.py             # Линейж штаммов
│   ├── revision.py            # Версии конструктов: import, commit, variant, diff
│   ├── assembly.py            # Assembly operations tracking
│   ├── search.py              # Поиск по features, последовательностям, RE сайтам
│   └── config.py              # Пути, конфигурация проекта
│
├── gui/
│   ├── designer/src/          # React Designer (2,008 строк)
│   │   ├── App.jsx            # Главный компонент: state, handlers, layout
│   │   ├── api.js             # Fetch обёртки для FastAPI
│   │   ├── validate.js        # Валидация конструкта на клиенте
│   │   ├── exports.js         # Экспорт GenBank, протокол, save to PVCS
│   │   └── components/
│   │       ├── PartsPalette.jsx        # Библиотека частей (drag source)
│   │       ├── DesignCanvas.jsx        # Рабочая область (drop target)
│   │       ├── PartBlock.jsx           # Блок фрагмента на canvas
│   │       ├── JunctionBlock.jsx       # Настройка стыка ◀/◀▶/▶
│   │       ├── JunctionDNA.jsx         # Визуализация праймеров на стыке
│   │       ├── SequenceViewer.jsx      # Просмотр последовательности
│   │       ├── PrimerPanel.jsx         # Таблица праймеров
│   │       ├── RestrictionPanel.jsx    # Рестрикционный анализ
│   │       ├── VerificationPanel.jsx   # Праймеры верификации
│   │       ├── SignalPeptideSplitter.jsx # Разрезание сигнального пептида
│   │       └── AddFragmentModal.jsx    # Добавление своих фрагментов
│   │
│   ├── api/server.py          # FastAPI бэкенд (210 строк, 8 endpoints)
│   │
│   └── gui/                   # Streamlit Dashboard (2,468 строк)
│       ├── app.py             # Точка входа
│       ├── style.css          # CSS тема
│       ├── _pages/            # Страницы (8 шт)
│       └── components/        # Визуальные компоненты (plasmid_map, diff_view...)
│
├── tests/                     # 72 теста (все проходят)
└── gui/constructs/            # 13 тестовых плазмид (.gb файлы)
```

### 1.4 Установка и запуск

**Зависимости:**
```bash
pip install -e "."                        # Backend (Biopython, Click, dataclasses)
cd gui/designer && npm install            # React (react, react-dnd, tailwind)
pip install streamlit --break-system-packages  # Streamlit GUI
pip install uvicorn fastapi               # API сервер
```

**Запуск:**
```bash
# Вариант 1: три терминала
cd gui/api && uvicorn server:app --port 8000 --reload     # FastAPI
cd gui/designer && npm run dev                             # React (порт 3000)
cd gui && streamlit run gui/app.py                         # Streamlit (порт 8501)

# Вариант 2: Windows
gui/run_designer.bat     # FastAPI + React
gui/run.bat              # Streamlit
```

---

## Часть II. Принципы построения логики

### 2.1 Junction-centric архитектура (ключевое решение)

Вся логика сборки построена вокруг стыков (junctions), а не методов. Традиционный подход — «выбери метод (Gibson/Overlap/GoldenGate) → система рассчитает всё». Наш подход:

1. Каждый **фрагмент** решает независимо: нужна ли ему ПЦР-амплификация?
2. Каждый **стык** решает независимо: как соединяются два соседних фрагмента?

Это разделение позволяет комбинировать методы в одной сборке: первый стык — overlap, второй — sticky_end, третий — Golden Gate. На практике это нужно, когда один фрагмент уже есть в пробирке (не нужна ПЦР), а другой нужно амплифицировать.

**Типы стыков (junction_type):**

| Тип | Описание | Что добавляется к праймеру |
|---|---|---|
| `overlap` | Overlap PCR / Gibson assembly | Tail = overlap sequence (15-35 bp) |
| `golden_gate` | Type IIS рестриктаза + 4-nt overhang | Tail = spacer + RE site + overhang |
| `sticky_end` | Классическая RE/ligation | Tail = TT spacer + RE site |
| `blunt` | Blunt-end ligation | Tail = пусто |
| `preformed` | Концы уже совместимы | Tail = пусто |
| `phosphorylated` | KLD (back-to-back) | Мутантный кодон в binding |

### 2.2 Gibson и Overlap PCR — одно и то же

Дизайн праймеров для Gibson assembly и Overlap PCR **идентичен**. Разница только в протоколе сборки в лаборатории:

- **Overlap PCR:** смешать фрагменты → 5 циклов без праймеров (фрагменты отжигаются друг на друга) → добавить внешние праймеры → 25 циклов → гель-очистка
- **Gibson:** смешать фрагменты + Gibson master mix → 50°C 1 час → трансформация
- **In-Fusion:** аналогично Gibson, но 50°C 15 мин

Поэтому в Designer нет кнопки «Gibson vs Overlap» на этапе дизайна. Переключатель «Overlap/Gibson» появляется на этапе экспорта протокола — после того как праймеры уже рассчитаны.

### 2.3 Overlap modes: куда идёт overlap?

Для каждого стыка overlap может быть распределён тремя способами:

**Split (◀▶):** overlap делится пополам. Левая половина идёт на rev праймер левого фрагмента, правая — на fwd праймер правого. При overlap = 30 bp каждый праймер получает ~15 bp хвост. Это стандартный режим когда оба фрагмента амплифицируются ПЦР.

**Left only (◀):** весь overlap идёт на rev праймер левого фрагмента. Правый фрагмент не получает хвоста. Используется когда правый фрагмент не амплифицируется (синтетический, из рестрикции).

**Right only (▶):** весь overlap идёт на fwd праймер правого фрагмента. Используется когда левый фрагмент не амплифицируется.

**Автоувеличение:** при выборе split mode, если overlap < 28 bp, система автоматически увеличивает его до 30 bp. Причина: при split каждый праймер получает половину overlap. 22 bp / 2 = 11 bp — ненадёжно для отжига. 30 bp / 2 = 15 bp — надёжно.

### 2.4 Binding region: подбор по Tm

Binding region праймера (часть, которая отжигается на темплейте) подбирается не по фиксированной длине, а по температуре плавления:

1. Начинаем с 18 bp
2. Рассчитываем Tm по модели ближайших соседей (SantaLucia, 1998)
3. Если Tm < целевой (60°C по умолчанию) — расширяем на 1 bp
4. Повторяем до достижения целевого Tm или максимума 28 bp
5. GC clamp: предпочитаем заканчивать на G или C

Коррекция Tm по полимеразе: Phusion/Q5 (+3°C), KOD (+2°C), Taq (−5°C).

### 2.5 Семантический diff (4 слоя)

Классический побуквенный diff бесполезен для плазмид: замена одного гена на другой показывается как 1000+ точечных мутаций. Семантический diff работает на уровне features:

**Layer 1: Выравнивание последовательностей** (Needleman-Wunsch)
**Layer 2: Извлечение необработанных различий** (участки несовпадений)
**Layer 3: Наложение features** (какой feature покрывает каждый участок)
**Layer 4: Агрегация** (если весь feature A заменён на feature B → «Replaced amy with bgl1»)

Результат: P42_pGAP_AMY vs P42_pGAP_BGII показывает 2 замены (а не 1153 побазовых мутаций).

### 2.6 Модель данных

```
Project ──┐
           ├── Construct ──┐
           │                ├── Revision (version, sequence, features)
           │                │    ├── Milestone (tag)
           │                │    └── AssemblyOperation (method, primers, status)
           │                └── Variant (branched construct)
           │
           ├── Part (reusable genetic element)
           │
           ├── Primer (universal registry)
           │
           ├── Strain (organism lineage)
           │
           └── AssemblyTemplate (slot-based blueprint)
                └── AssemblyPlan (concrete steps)
```

---

## Часть III. React Construct Designer — каждый компонент

### 3.1 App.jsx — главный компонент (400 строк)

**State (17 переменных):**

| Переменная | Тип | Назначение |
|---|---|---|
| `parts` | `Part[]` | Библиотека частей из API |
| `fragments` | `Fragment[]` | Фрагменты на canvas (в порядке 5'→3') |
| `junctions` | `Junction[]` | Стыки между фрагментами |
| `assemblyType` | `'overlap' \| 'golden_gate'` | Тип сборки (влияет на тип стыков) |
| `protocol` | `string` | Протокол для экспорта (overlap_pcr/gibson/infusion) |
| `primers` | `Primer[]` | Рассчитанные праймеры |
| `circular` | `boolean` | Кольцевой или линейный конструкт |
| `calculated` | `boolean` | Праймеры рассчитаны? (для визуализации) |
| `polymerase` | `string` | Полимераза (для коррекции Tm) |
| `primerPrefix` | `string` | Префикс имён праймеров (IS001_fwd) |
| `splitTarget` | `number \| null` | Индекс CDS для SignalPeptideSplitter |
| `steps` | `Step[]` | Шаги мультистадийной сборки |
| `activeStep` | `number` | Активный шаг (-1 = основной canvas) |

**Ключевые функции:**

`mkJunctions(frags, asmType, isCirc)` — создаёт массив junction-объектов. Количество: `isCirc ? frags.length : frags.length - 1`. Замыкающий junction (circular) соединяет последний фрагмент с первым.

`addFragment(part)` — добавляет часть из палитры на canvas. Создаёт fragment-объект, добавляет в массив, пересоздаёт junctions.

`generate()` — вызывает `POST /api/design/primers`, передаёт fragments + junctions + circular. Получает primers + warnings + orderSheet. Переименовывает праймеры с префиксом (IS001_fwd). Корректирует Tm по полимеразе.

`handleSignalSplit(result)` — обрабатывает результат от SignalPeptideSplitter. Четыре действия: remove (убрать сигнал), replace (заменить на glaA_ss), split_only (разбить на два), keep (ничего).

**Persistence:** state сохраняется в `localStorage` при каждом изменении. При загрузке — восстанавливается. Ключ: `pvcs-designer-state`.

### 3.2 PartsPalette.jsx — библиотека частей (82 строки)

Левая панель. При монтировании загружает части через `GET /api/parts`. Если API недоступен — использует fallback demo parts (10 штук: PglaA, PgpdA, XynTL, PyrG, Cas9, TtrpC, TglaA, amdS, pUC_ori, ama1).

Части группируются по `type`: CDS, promoter, terminator, marker, rep_origin. Поиск фильтрует по имени (case-insensitive).

Каждая часть — drag source (react-dnd). При перетаскивании на canvas вызывается `addFragment(part)`.

Внизу три кнопки открывают `AddFragmentModal`:
- «Из пробирки / ПЦР-продукта» (mode: composite)
- «Извлечь из конструкта» (mode: construct)
- «Вставить последовательность» (mode: sequence)

### 3.3 DesignCanvas.jsx — рабочая область (89 строк)

Drop target для частей из палитры. Фрагменты выстраиваются горизонтально, 5'→3'. Между фрагментами — junction блоки.

5'-конец обозначен серой полоской слева, 3' — справа.

Кнопка Circular/Linear переключает топологию. При circular добавляется замыкающий junction + метка «→1st».

Нижняя строка: «Итого: 2.5 kb линейный · 3 фрагмента · 2 стыка».

### 3.4 PartBlock.jsx — блок фрагмента (96 строк)

Цветной прямоугольник на canvas. Цвет определяется типом фрагмента (Okabe-Ito палитра). При наведении — кнопка удаления (×). Для CDS — кнопка ✂ (split signal peptide).

Drag source для перестановки (reorder). При перетаскивании на позицию другого фрагмента — меняются местами.

Под блоком: размер (в bp или kb), PCR product size (если рассчитан).

Чередование оттенков: если два соседних фрагмента одного типа, второй получает затемнённый на 15% цвет.

### 3.5 JunctionBlock.jsx — настройка стыка (134 строки)

При клике открывается popover с настройками. Для типа `overlap`:
- Три кнопки ◀ / ◀▶ / ▶ (left_only, split, right_only)
- Длина overlap (число, range 15-45)
- Целевой Tm overlap зоны

Для типа `golden_gate`:
- Фермент (BsaI, BbsI, Esp3I, BpiI, SapI)
- 4-нуклеотидный overhang (текстовое поле)

Для типа `sticky_end`:
- Фермент рестрикции (EcoRI, BamHI, HindIII...)

Лейбл на canvas: `◀▶30bp` или `GG:ATCG` или `EcoRI`.

### 3.6 JunctionDNA.jsx — визуализация на стыке (77 строк)

До расчёта праймеров: простой лейбл с размером overlap.

После расчёта: показывает как праймеры ложатся на обе последовательности:

```
  rev_PglaA: atcgatcgatcg ATCGATCGATCG ←
             (tail=overlap) (binding on PglaA)

  fwd_XynTL: gctagctagcta GCTAGCTAGCTA →
             (tail=overlap) (binding on XynTL)
```

Цветовое кодирование:
- Бирюзовый строчной = tail (overlap)
- Красный жирный + стрелка ← = reverse primer binding
- Синий жирный + стрелка → = forward primer binding
- Серый = template DNA за пределами праймеров

### 3.7 SequenceViewer.jsx — просмотр последовательности (186 строк)

Показывает полную последовательность конструкта. Каждый фрагмент окрашен своим цветом. Разделитель | на границах.

Кнопки-вкладки: All (весь конструкт), или отдельный фрагмент.

После расчёта праймеров — их позиции отображаются стрелками: forward (→) синим, reverse (←) красным.

Формат: моноширинный шрифт, 60 символов на строку, группы по 10.

«Copy sequence» копирует всю последовательность в буфер.

### 3.8 PrimerPanel.jsx — таблица праймеров (96 строк)

Таблица: имя, последовательность, Tm binding, GC%, длина, назначение tail.

Последовательность отображается: `atcgatcg` (tail строчные бирюзовые) + `ATCGATCG` (binding прописные жирные).

Цвет Tm: зелёный = 58-64°C, оранжевый = вне диапазона.

Бейджи качества рядом с каждым праймером:
- 🔴 3' self-complementary
- 🟡 No GC clamp
- 🟡 Homopolymer run
- 🔴 Very long (>55 nt) — PAGE purification

Кнопка «Copy for ordering (TSV)» копирует таблицу в формате: имя \t последовательность \t масштаб \t очистка.

### 3.9 RestrictionPanel.jsx — рестрикционный анализ (136 строк)

Разворачивается кнопкой «🔬 Restriction Analysis».

Пресеты ферментов: Common cloning (EcoRI, BamHI...), Golden Gate (BsaI, BbsI...), Verification.

Таблица результатов: фермент, сайт узнавания, количество разрезов, позиции, в каком фрагменте.

Цветовое кодирование: 0 разрезов = серый, 1 разрез (unique cutter) = зелёный фон, 2+ = обычный.

Блок «Unique cutters» подсвечен зелёным.

**Диагностическая рестрикция:** выбрать 1-3 фермента → система моделирует гель-электрофорез: показывает ожидаемые фрагменты с размерами и визуализацией полосок (log шкала).

### 3.10 VerificationPanel.jsx — праймеры верификации (84 строки)

Разворачивается кнопкой «🧫 Verification Primers».

**Colony PCR:** fwd = первые 22bp конструкта, rev = reverse complement последних 22bp. Ожидаемый размер.

**Sequencing primers:** если вставка > 1500 bp — автоматически рассчитываются внутренние секвенирующие праймеры каждые ~700 bp (максимальная длина чтения Sanger).

Кнопка «Copy verification primers (TSV)».

### 3.11 SignalPeptideSplitter.jsx — сигнальный пептид (114 строк)

Модальное окно. Открывается при клике ✂ на CDS фрагменте.

**Алгоритм предсказания:**
1. Транслировать ДНК → белок
2. Сканировать окно 15-35 аминокислот от N-конца
3. Для каждой позиции: hydrophobicity score (A,V,L,I,F,W,M) + von Heijne score (small-X-small на -3..-1 от cleavage) + charge bonus (K,R в первых 5 aa)
4. Позиция с максимальным score = предсказанный сайт расщепления

**Действия:**
- Remove signal → удалить первые N×3 bp, оставить зрелый белок
- Replace with glaA_ss → удалить нативный сигнал, вставить glaA signal peptide
- Keep native → закрыть без изменений
- Split into two → разбить CDS на два фрагмента: [signal_ss] + [mature]

Ползунок для ручной настройки позиции расщепления (aa 5-50).

### 3.12 AddFragmentModal.jsx — добавление фрагментов (218 строк)

Три режима:

**sequence:** пользователь вводит имя, тип, последовательность вручную. Для синтетических генов, из GenBank.

**composite:** ПЦР-продукт из морозилки. Имя, последовательность, sub-parts (что внутри: PglaA + XynTL). Галочка «Needs PCR» — снять если используется прямо из пробирки.

**construct:** выбрать конструкт из базы данных → выбрать feature → извлечь последовательность.

### 3.13 validate.js — валидация конструкта (97 строк)

Три экспортируемые функции:

**`validateConstruct(fragments)`** — проверяет:
- CDS начинается с ATG
- CDS длина кратна 3 (нет frameshift)
- Нет внутренних стоп-кодонов (TAA/TAG/TGA) кроме последнего
- Есть стоп-кодон в конце CDS
- Промотор перед CDS (не CDS без промотора)
- Терминатор перед промотором = вероятно обратный порядок
- Два промотора подряд
- CDS без терминатора в конце конструкта

**`checkPrimerQuality(primer)`** — проверяет:
- 3' self-complementarity (последние 4 bp = RC участка внутри)
- GC clamp (последние 2 bp содержат G или C)
- Homopolymer run (5+ одинаковых нуклеотидов подряд)
- Длина > 55 nt → PAGE purification

**`pcrProductSize(frag, leftJ, rightJ)`** — размер ПЦР-продукта = длина фрагмента + длины overlap-хвостов от соседних junction.

### 3.14 exports.js — экспорт (142 строки)

**`exportGenBank(fragments, name, circular)`** — генерирует .gb файл:
- LOCUS (имя, длина, topology, дата)
- FEATURES (каждый фрагмент как feature с /label)
- ORIGIN (последовательность в формате GenBank: 60bp/строка, группы по 10)
- Скачивает файл через Blob + <a>.

**`exportProtocol(fragments, junctions, primers, method, circular)`** — текстовый протокол:
- Для каждого фрагмента: template, primers, annealing Tm, expected size
- Для overlap PCR: fusion PCR программа
- Для Gibson: mix + master mix + 50°C 60 мин
- Для Golden Gate: 30 циклов 37°C/16°C

**`saveToPVCS(fragments, junctions, primers, method, circular, name)`** — POST на `/api/assembly/create`.

### 3.15 api.js — запросы к API (47 строк)

| Функция | Endpoint | Назначение |
|---|---|---|
| `fetchParts(type?)` | GET /api/parts | Загрузить библиотеку частей |
| `fetchConstructs()` | GET /api/constructs | Список конструктов |
| `fetchFeatures(id)` | GET /api/constructs/{id}/features | Features конструкта |
| `designPrimers(...)` | POST /api/design/primers | Рассчитать праймеры |
| `validateGoldenGate(...)` | POST /api/validate/golden-gate | Проверить GG overhangs |
| `calcTm(sequence)` | POST /api/calc/tm | Рассчитать Tm |

---

## Часть IV. FastAPI Backend — endpoints

### 4.1 POST /api/design/primers

**Тело запроса:**
```json
{
  "fragments": [
    {"name": "PglaA", "sequence": "ATCG...", "needsAmplification": true}
  ],
  "junctions": [
    {"type": "overlap", "overlapMode": "split", "overlapLength": 30, "tmTarget": 62}
  ],
  "method": "overlap_pcr",
  "circular": false,
  "bindingTmTarget": 60.0
}
```

**Логика:**
1. Создаёт `AssemblyFragment` для каждого фрагмента
2. Для каждого junction типа `overlap` — вызывает `design_overlap_junction(leftSeq, rightSeq, length, tm)`
3. Для circular: замыкающий junction соединяет `frags[-1]` с `frags[0]` (`right_idx = (i+1) % n_frags`)
4. Вызывает `generate_primers_for_step(frags, juncs, circular, bindingTmTarget)`
5. Возвращает: primers, junctions (с overlap sequences), warnings, orderSheet

### 4.2 POST /api/validate/golden-gate

Проверяет overhang-ы: уникальность, палиндромы. Проверяет внутренние сайты ферментов. Возвращает warnings.

### 4.3 POST /api/restriction/check

Ищет RE сайты в последовательности. Поддерживает forward и reverse complement. Возвращает позиции (1-based).

### 4.4 POST /api/calc/tm

Расчёт Tm по модели ближайших соседей (SantaLucia). Параметры: dna_conc_nm (250), salt_mm (50).

---

## Часть V. Ядро системы (src/pvcs/)

### 5.1 assembly_engine.py — движок сборки (339 строк)

Центральный модуль. Два класса данных + три функции.

**`AssemblyFragment`** — фрагмент в сборке: order, name, sequence, needs_amplification, source_type.

**`JunctionSpec`** — спецификация стыка: junction_type, overlap_mode, overlap_sequence, overlap_length, overlap_tm, enzyme, overhang_4nt, re_enzyme.

**`generate_primers_for_step(frags, juncs, circular, binding_tm_target)`** — основная функция:

Для каждого фрагмента с `needs_amplification=True`:
1. Найти левый и правый junction
2. Для fwd праймера: tail = `_compute_fwd_tail(left_junction)`, binding = первые N bp фрагмента (по Tm)
3. Для rev праймера: tail = `_compute_rev_tail(right_junction)`, binding = последние N bp фрагмента (RC, по Tm)
4. Вернуть `StepResult(primers, warnings)`

**`_compute_fwd_tail(junction)`** — вычисляет tail для fwd праймера:
- `overlap` + `split`: первая половина overlap sequence
- `overlap` + `right_only`: весь overlap sequence
- `overlap` + `left_only`: пусто (overlap на другом праймере)
- `golden_gate`: spacer + RE site + overhang
- `sticky_end`: TT + RE site
- `blunt`/`preformed`: пусто

**`design_overlap_junction(left_seq, right_seq, length, tm_target)`** — конструирует overlap zone: берёт `length/2` bp с конца левого и начала правого фрагмента, проверяет Tm, расширяет если нужно.

### 5.2 overlap.py — overlap дизайн (350 строк)

**`_select_binding_region(sequence, tm_target, salt_mm)`** — подбирает binding region по Tm:
- Начинает с 18 bp
- Расширяет по 1 bp пока Tm < target или длина < 28 bp
- Предпочитает заканчиваться на G/C (GC clamp)

**`design_overlaps(fragments, overlap_length, tm_target, split_mode)`** — дизайн всех overlap зон для массива фрагментов. Старая функция, используется CLI. Designer использует `assembly_engine.py`.

### 5.3 golden_gate.py — Golden Gate (213 строк)

**`suggest_overhangs(n_junctions)`** — предлагает набор уникальных 4-nt overhang-ов. Исключает палиндромы.

**`check_overhang_uniqueness(overhangs)`** — проверяет: нет ли дубликатов? нет ли палиндромов? Палиндромный overhang (ATAT, GCGC, CATG) не даёт направленной сборки.

**`check_internal_sites(sequence, enzyme_site)`** — ищет сайт фермента внутри фрагмента. Если найден — фрагмент нужно «доместицировать» (тихая мутация).

**`design_golden_gate(fragments, enzyme, overhangs)`** — полный дизайн GG сборки.

### 5.4 kld.py — KLD мутагенез (207 строк)

Три функции для трёх типов мутаций:

**`design_kld_point_mutation(template, position, new_codon)`** — замена кодона. fwd праймер начинается с мутантного кодона + binding downstream. rev праймер = binding upstream (back-to-back). Оба 5'-фосфорилированы.

**`design_kld_deletion(template, start, end)`** — делеция. fwd начинается сразу после удалённого участка. rev заканчивается перед ним. Праймеры «перепрыгивают» удалённый участок.

**`design_kld_insertion(template, position, insert_sequence)`** — инсерция. Вставляемая последовательность идёт в tail fwd праймера.

### 5.5 restriction.py — рестрикционный анализ (195 строк)

**`RE_DATABASE`** — 21 фермент: EcoRI, BamHI, HindIII, XbaI, SalI, NcoI, NdeI, XhoI, NotI, PstI, SphI, EcoRV, SmaI, StuI, KpnI, SacI, NheI, BglII, ClaI, MfeI, AgeI. Каждый: site, cut position, end type (5prime/3prime/blunt), overhang.

**`find_sites(sequence, enzyme)`** — ищет все сайты фермента в последовательности (forward + reverse complement). Возвращает позиции (1-based).

**`check_compatible_ends(enzyme_5, enzyme_3)`** — проверяет совместимость sticky ends. Совместимые пары: EcoRI+MfeI, BamHI+BglII, XbaI+SpeI, SalI+XhoI, SmaI+EcoRV (blunt).

**`design_re_primers(insert, enzyme_5, enzyme_3)`** — дизайн праймеров для рестрикционно-лигазного клонирования. fwd = TT spacer + 5' RE site + binding. rev = TT spacer + 3' RE site RC + binding RC. Проверяет внутренние сайты в инсерте.

### 5.6 diff.py — семантический diff (473 строки)

**`semantic_diff(rev_a, rev_b)`** — 4-слойный diff между двумя ревизиями. Возвращает `SemanticDiff` со списком `Change` объектов. Каждый Change: type (insertion/deletion/replacement/mutation), position, length, description, affected_features.

### 5.7 parser.py — парсинг файлов (220 строк)

**`parse_genbank(filepath)`** — Biopython → (sequence, features[], metadata). Извлекает имя feature из /label, /gene, /product.

**`infer_feature_type(name, ftype)`** — вывод типа по имени. Правила:
- Начинается с `P`/`p` + есть гласная → promoter (PglaA, PgpdA, pgap)
- Начинается с `T`/`t` + 3+ символа → terminator (TtrpC, TglaA)
- Содержит `ori`, `ama`, `rep` → rep_origin
- `R`/`r` в конце (HygR, NatR) или известные гены (Cas9, GFP, pyrG) → CDS

**`genbank_to_revision(filepath, construct_name, version)`** — парсит файл и создаёт Revision.

**`write_genbank(revision, filepath)`** — записывает Revision обратно в .gb файл.

### 5.8 utils.py — утилиты (293 строки)

**`calc_tm(sequence, dna_conc_nm, salt_mm)`** — Tm по ближайшим соседям (SantaLucia, 1998). Guard: <6 bp → возвращает 0.

**`reverse_complement(sequence)`** — A↔T, G↔C, переворот строки.

**`gc_content(sequence)`** — доля G+C в последовательности (0.0 — 1.0).

**`translate_sequence(sequence, frame)`** — трансляция ДНК → белок. Стандартный код.

**`sequence_checksum(sequence)`** — SHA-256 хеш для дедупликации.

### 5.9 feature_db.py — база known features (603 строки)

21 запись: PglaA, PgpdA, PcbhI, TtrpC, TglaA, TcbhI, pyrG_Af, pyrG_An, hygR, amdS, Cas9_opt, GFP, mCherry, lacZ, ampR, kanR, pUC_ori, ama1, ARS, CEN, f1_ori. Каждая: name, type, organism, reference_sequence, length, description.

**`detect_known_features(sequence)`** — ищет known features в последовательности. (На данный момент последовательности — placeholder, нужно наполнить реальными данными.)

### 5.10 database.py — SQLite (745 строк)

CRUD операции для всех моделей. Таблицы создаются автоматически при первом подключении. Основные функции:

- `insert_construct / get_construct_by_name / list_constructs`
- `insert_revision / get_revision / get_latest_revision / list_revisions`
- `insert_part / get_part_by_name / list_parts`
- `insert_primer / get_primer_by_name / list_primers`
- `insert_assembly_operation / get_assembly_operation / update_assembly_status`
- `insert_assembly_plan / update_step_status / update_plan_status`
- `search_features` — полнотекстовый поиск по features

---

## Часть VI. Streamlit Dashboard — страницы

### 6.1 Dashboard (p01_dashboard.py, 109 строк)
Обзор проекта: количество конструктов, частей, праймеров. Список последних конструктов с мини-картами.

### 6.2 Construct Viewer (p02_construct.py, 142 строки)
Выбрать конструкт → показать: кольцевая/линейная карта (SVG), таблица features, последовательность, история версий.

### 6.3 Diff (p03_diff.py, 181 строка)
Выбрать два конструкта (или две версии одного) → семантический diff. Показывает: «Replaced amy with bgl1» вместо 1153 побазовых мутаций.

### 6.4 Strains (p04_strains.py, 76 строк)
Линейж штаммов: AN-001 (WT) → AN-002 (ΔkusA) → AN-003 (ΔkusA pyrG⁻). Дерево штаммов.

### 6.5 Parts (p05_parts.py, 153 строки)
Библиотека частей: промоторы, CDS, терминаторы, маркеры. Добавление, поиск.

### 6.6 Primers (p06_primers.py, 99 строк)
Реестр всех праймеров: имя, последовательность, Tm, к какому конструкту привязан.

### 6.7 Assembly (p07_assembly.py, 687 строк)
Assembly wizard в Streamlit (параллелен React Designer). Пошаговая сборка с настройками.

### 6.8 Import (p08_import.py, 255 строк)
Импорт .gb, .fasta, .dna (SnapGene) файлов. Автоматический парсинг features, определение типов.

---

## Часть VII. CLI — команды

### 7.1 Управление проектом
```bash
pvcs init --name "MyProject" --author "Igor Sinelnikov"
pvcs import file.gb --name "P42_pGAP_AMY" --message "Initial import"
pvcs commit file.gb --construct "P42_pGAP_AMY" --version "1.1" --message "Replaced amy with bgl1"
pvcs variant "P42_pGAP_AMY" --name "P42_pGAP_BGII" --from-version "1.0"
```

### 7.2 Просмотр и сравнение
```bash
pvcs log "P42_pGAP_AMY"                    # История версий
pvcs tree "P42_pGAP_AMY"                   # Дерево вариантов
pvcs diff "P42_pGAP_AMY:1.0" "P42_pGAP_AMY:1.1"   # Семантический diff
pvcs search "glaA" --feature                 # Поиск по features
```

### 7.3 Библиотека частей
```bash
pvcs part add promoter.gb --name "PglaA" --type promoter --organism "A. niger"
pvcs part list --type CDS
```

### 7.4 Дизайн overlap
```bash
pvcs overlap design construct.gb --split both --overlap-length 30 --tm-target 62
```

### 7.5 Праймеры
```bash
pvcs primer list
pvcs primer show "fwd_PglaA"
pvcs primer find --binds-to "PglaA"        # Найти все праймеры к feature
pvcs primer check-reuse "P42:1.0"           # Проверить есть ли готовые праймеры
```

### 7.6 Штаммы
```bash
pvcs strain add "AN-002" --name "ΔkusA" --parent "AN-001" --construct "P42_pGAP_AMY"
pvcs strain tree "AN-001"                   # Дерево от WT
pvcs strain list
```

### 7.7 Экспорт
```bash
pvcs export "P42_pGAP_AMY" --format genbank --output out.gb
pvcs export "P42_pGAP_AMY" --format yaml --output out.yaml
pvcs export "P42_pGAP_AMY" --format html --output out.html    # Визуальный отчёт
```

### 7.8 Assembly tracking
```bash
pvcs assembly status                        # Статус всех сборок
pvcs assembly set "P42_pGAP_AMY" --status "pcr_done" --note "All fragments amplified"
```

---

## Часть VIII. Типичные workflow

### 8.1 Сборка экспрессионной кассеты (Overlap PCR)

1. Открыть Designer (localhost:3000)
2. Из палитры перетащить: PglaA → XynTL → TtrpC
3. Настроить каждый стык: ◀▶ (split), 30bp, Tm 62°C
4. Нажать «Generate Primers» → 6 праймеров
5. Проверить предупреждения (ATG, frameshift, порядок)
6. Открыть Restriction Analysis → проверить отсутствие нежелательных сайтов
7. Экспорт GenBank (.gb) для SnapGene
8. Экспорт TSV для заказа праймеров

### 8.2 Вставка гена в вектор (Restriction/Ligation)

1. Добавить ген (CDS) на canvas
2. Добавить backbone (needs_amplification = false)
3. Тип стыков: sticky_end
4. 5'-junction: EcoRI, 3'-junction: BamHI
5. Generate Primers → 2 праймера (только для гена, backbone режется рестриктазами)

### 8.3 Замена сигнального пептида

1. Добавить CDS с нативным сигналом на canvas
2. Нажать ✂ на CDS
3. Выбрать «Replace with glaA_ss»
4. Система: удаляет нативный сигнал, вставляет glaA_ss как отдельный фрагмент
5. Между glaA_ss и mature CDS — overlap junction

### 8.4 Мутагенез (KLD)

1. Кнопка «🔬 Мутагенез» (будущая фича)
2. Выбрать конструкт из базы
3. Указать мутацию: Q158R (позиция 158, Gln → Arg)
4. Система выбирает стратегию:
   - 1 мутация → KLD (back-to-back праймеры)
   - 3+ мутаций → нарезка на фрагменты + overlap PCR

---

## Часть IX. Типичные ошибки

| # | Ошибка | Автодетекция | Решение |
|---|---|---|---|
| 1 | CDS без ATG | ⚠ в validate.js | Проверить начало CDS |
| 2 | Frameshift (длина не ×3) | ⚠ в validate.js | Проверить границы feature |
| 3 | Двойной сигнальный пептид | ⚠ если signal_peptide + CDS с нативным SP | Использовать ✂ |
| 4 | Терминатор перед промотором | 💡 подсказка | Переставить drag-and-drop |
| 5 | Overlap < 28bp при split | Автоувеличение до 30bp | - |
| 6 | Забыл Circular | Нет замыкающего junction | Включить Circular |
| 7 | Внутренний BsaI | Автодетекция в GG | Доместикация |
| 8 | Праймеры > 55 nt | ⚠ quality check | Заказать PAGE |
| 9 | Не проверил RE сайты | Нет автодетекции | Открыть Restriction Analysis |
| 10 | Нет verification primers | Нет автодетекции | Открыть Verification panel |

---

## Часть X. Справочник

### 10.1 RE_DATABASE (21 фермент)

| Фермент | Сайт | Тип конца | Overhang |
|---|---|---|---|
| EcoRI | GAATTC | 5' overhang | AATT |
| BamHI | GGATCC | 5' overhang | GATC |
| HindIII | AAGCTT | 5' overhang | AGCT |
| XbaI | TCTAGA | 5' overhang | CTAG |
| SalI | GTCGAC | 5' overhang | TCGA |
| NcoI | CCATGG | 5' overhang | CATG |
| NdeI | CATATG | 5' overhang | TA |
| XhoI | CTCGAG | 5' overhang | TCGA |
| NotI | GCGGCCGC | 5' overhang | GGCC |
| PstI | CTGCAG | 3' overhang | CTGCA |
| KpnI | GGTACC | 3' overhang | GTAC |
| SacI | GAGCTC | 3' overhang | AGCT |
| SmaI | CCCGGG | Blunt | — |
| EcoRV | GATATC | Blunt | — |
| StuI | AGGCCT | Blunt | — |
| NheI | GCTAGC | 5' overhang | CTAG |
| BglII | AGATCT | 5' overhang | GATC |
| ClaI | ATCGAT | 5' overhang | CG |
| MfeI | CAATTG | 5' overhang | AATT |
| AgeI | ACCGGT | 5' overhang | CCGG |
| SphI | GCATGC | 3' overhang | CATG |

### 10.2 Golden Gate ферменты

| Фермент | Сайт | Cut offset |
|---|---|---|
| BsaI | GGTCTC | +1 |
| BbsI | GAAGAC | +2 |
| Esp3I | CGTCTC | +1 |
| BpiI | GAAGAC | +2 |
| SapI | GCTCTTC | +1 |

### 10.3 Совместимые sticky ends

| Пара | Overhang | Примечание |
|---|---|---|
| EcoRI + MfeI | AATT | Лигируются, не перерезаются ни одним |
| BamHI + BglII | GATC | Лигируются, не перерезаются ни одним |
| SalI + XhoI | TCGA | Лигируются, не перерезаются ни одним |
| XbaI + SpeI | CTAG | BioBrick-совместимые |
| NcoI + BspHI | CATG | Совместимые |
| SmaI + EcoRV | Blunt | Совместимы (оба blunt) |

---

*Конец документа. Версия 1.0, март 2026.*


---

## Часть XI. Protocol Tracker — лабораторный журнал

### 11.1 Концепция

После генерации праймеров Designer знает ВСЕ шаги которые нужно сделать в лаборатории. ProtocolTracker — пошаговый лабораторный журнал, который автоматически генерируется из данных сборки. Появляется как вкладка «📋 Протокол» рядом с «Последовательность» и «Праймеры».

Замкнутый цикл: дизайн → протокол → измерения → inventory → следующий дизайн. Каждое измерение концентрации автоматически попадает в библиотеку частей.

### 11.2 Автогенерируемые шаги

Для каждой сборки система создаёт следующие шаги:

| # | Тип шага | Что генерируется | Что заполняет студент |
|---|---|---|---|
| 1-N | ПЦР фрагмента | Микс, программа, праймеры, ожидаемый размер | Фото геля, фактический размер |
| 1.1-N.1 | Очистка | Рекомендованный метод, протокол | Конц-ция, объём, A260/280 |
| N+1 | Сборка | Протокол (Overlap/Gibson/GG), объёмы | Фото геля, комментарий |
| N+2 | Очистка сборки | Gel squeeze + реамплификация (для OV PCR) | Конц-ция |
| N+3 | Трансформация | Штамм, метод, селекция | Количество колоний, фото чашки |
| N+4 | Colony PCR | Микс (Taq), verification primers | Результаты по колониям |
| N+5 | Мини-преп | Протокол (E. coli kit / A. niger CTAB) | Конц-ция плазмиды |
| N+6 | Секвенирование | Праймеры, количество реакций | .ab1 файлы, статус |

### 11.3 ПЦР миксы (4 полимеразы)

Система хранит рецепты для четырёх полимераз:

**Phusion HF (50 µl):** 5× HF Buffer 10 µl, dNTPs 1 µl, праймеры по 2.5 µl, матрица 1 µl, Phusion 0.5 µl, H₂O 32.5 µl. Extension: 30 сек/кб при 72°C. Denature: 98°C.

**Taq (50 µl):** 10× Buffer 5 µl, MgCl₂ 3 µl, dNTPs 1 µl, праймеры по 2.5 µl, матрица 1 µl, Taq 0.5 µl, H₂O 34.5 µl. Extension: 60 сек/кб при 72°C. Denature: 95°C.

**KOD One (50 µl):** 2× Master Mix 25 µl, праймеры по 1.5 µl, матрица 1 µl, H₂O 21 µl. Extension: 20 сек/кб при 68°C (!).

**Colony PCR Taq (25 µl):** Уменьшенный объём. Initial denature 10 мин (лизис клеток). Колонию вносят зубочисткой.

Annealing temperature подставляется автоматически из рассчитанного Tm binding. Extension time рассчитывается по размеру продукта.

### 11.4 Методы очистки (5 вариантов)

| Метод | Время | Выход | Когда использовать |
|---|---|---|---|
| PCR cleanup (колонка) | 15 мин | 80-95% | Стандарт после ПЦР, убирает праймеры/dNTPs |
| Gel extraction (колонка) | 70 мин | 50-80% | Неспецифика на геле, нужна полоса конкретного размера |
| EtOH преципитация | 55 мин | 70-90% | Концентрирование, дёшево, не нужен kit |
| Gel squeeze + реамплификация | 60 мин + ПЦР | для ПЦР-матрицы | После overlap PCR: вырезать, отжать, 1 µl → ПЦР с концевых праймеров |
| Без очистки | 0 | 100% | Gibson/Golden Gate → трансформация напрямую |

Система автоматически рекомендует метод: перед сборкой → gel extraction; после overlap PCR → gel squeeze; после Gibson → без очистки.

### 11.5 Расчёт объёмов для сборки

Когда студент ввёл концентрации всех ПЦР-продуктов, система рассчитывает конкретные объёмы:

**Формула:** объём (µl) = целевая масса (нг) / концентрация (нг/µl)

Целевая масса: 50 нг для Gibson/Overlap, 75 нг для Golden Gate. Система выводит таблицу «пипетировать X µl PglaA, Y µl XynTL, Z µl TtrpC + Master Mix + H₂O до 20 µl».

### 11.6 Расчёт времени (Timeline)

Система рассчитывает полный таймлайн:

- **День 1** (~6-8 часов): все ПЦР (параллельно или последовательно) + гели + очистки + сборка + трансформация
- **Ночь:** колонии растут
- **День 2** (~2-3 часа): colony PCR + гель + отправка на секвенирование
- **День 3-4:** ожидание секвенирования → подтверждение

Чекбокс «Параллельные ПЦР» переключает расчёт: одна ПЦР-машина (последовательно) vs несколько (параллельно).

### 11.7 Выделение плазмиды (мини-преп)

Два протокола: мини-преп из E. coli (стандартный kit, 45 мин) и выделение геномной ДНК из A. niger (CTAB, 100 мин). Выбирается в зависимости от организма. После мини-преп — ConcentrationInput для измерения.

### 11.8 Статусы и прогресс

Каждый шаг имеет статус-чипы: «Не начат» → «В работе» → «Готово». Общий прогресс виден на Timeline. Все данные (фото гелей как base64, концентрации, комментарии) хранятся в localStorage.

---

## Часть XII. Inventory — учёт фрагментов и плазмид

### 12.1 Концепция

Каждое измерение концентрации (ConcentrationInput) автоматически создаёт запись в inventory (localStorage). Inventory показывается в палитре частей как две новые секции:

- **🧪 Имеющиеся ПЦР-продукты** — фрагменты с известной концентрацией
- **💊 Подтверждённые плазмиды** — конструкты после успешного секвенирования

### 12.2 Запись inventory

```
{
  id, name, type (pcr_product|plasmid|digest),
  sequence, length,
  concentration (нг/µл), volume (µл), totalDNA (нг),
  method (nanodrop|qubit|gel), a260_280, a260_230,
  location (морозилка, штатив, позиция),
  date, source (из какого шага протокола),
  verified (подтверждён секвенированием?)
}
```

### 12.3 Интеграция с палитрой

Когда студент перетаскивает фрагмент из «Имеющиеся ПЦР-продукты» на canvas — он автоматически получает `needsAmplification: false` (не нужна ПЦР — уже в пробирке) и реальную концентрацию. Система использует эти данные при расчёте объёмов для сборки.

### 12.4 Подтверждение конструкта

Когда секвенирование подтверждено, конструкт помечается как verified и автоматически сохраняется как Part в PlasmidVCS через API + появляется в inventory как «плазмида».

---

## Часть XIII. Мутагенез

### 13.1 Три типа мутаций

- **Substitution** (замена кодона): Q158R, A203G — замена одного кодона на другой
- **Deletion** (делеция): удалить участок ДНК
- **Insertion** (инсерция): вставить последовательность (линкер, тэг)

### 13.2 Три стратегии (автовыбор)

**KLD (1 мутация):** Back-to-back праймеры на кольцевом темплейте. fwd начинается с мутантного кодона, rev заканчивается перед ним. Оба 5'-фосфорилированы. ПЦР целой плазмиды → DpnI 1ч → KLD mix 5 мин → трансформация.

**KLD double (2 близкие мутации, <100 п.н.):** Обе мутации кодируются в binding regions праймеров одной KLD реакции.

**Fragment assembly (2+ далёкие мутации):** Ген разрезается на фрагменты между мутациями. Каждая мутация попадает в overlap zone. Все фрагменты амплифицируются с ОДНОГО темплейта. Мутации закодированы в overlap-хвостах праймеров. Собирается overlap PCR.

### 13.3 MutagenesisWizard — 3 шага

1. **Выбор темплейта** — из конструктов в базе или paste последовательности. Выбор целевого CDS.
2. **Определение мутаций** — тип, позиция (а.о.), целевая аминокислота, выбор кодона (с учётом codon usage организма).
3. **Стратегия** — система автоматически выбирает KLD или fragment assembly, показывает план, праймеры, протокол. Кнопка «Apply to Canvas» кладёт фрагменты на обычный canvas.

### 13.4 Codon usage

Таблица частот кодонов для 5 организмов: A. niger, E. coli, S. cerevisiae, T. reesei, P. pastoris. При замене аминокислоты система показывает все синонимичные кодоны отсортированные по частоте для целевого организма.

### 13.5 Валидации мутагенеза

- Мутация не создаёт стоп-кодон
- Делеция/инсерция не вызывает frameshift (длина кратна 3)
- Проверка: мутация создаёт/уничтожает RE сайт (полезно для скрининга!)
- Напоминание про DpnI и 5'-фосфорилирование (для KLD)

---

## Часть XIV. Обработка интронов

### 14.1 Парсинг из GenBank

CDS с интронами записан в GenBank как `join(1..200,350..800,950..1200)` — три экзона, два интрона. Biopython парсит CompoundLocation, система извлекает границы экзонов и интронов автоматически. Показывает интроны серым на SequenceViewer.

### 14.2 Детекция через cDNA-alignment (mappy)

Когда студент имеет геномную ДНК + cDNA последовательность — `mappy` (Python bindings minimap2) выравнивает за миллисекунды. Интроны = 'N' операции в CIGAR. Splice-aware preset, GT-AG donor/acceptor сайты.

API endpoint: `POST /api/introns/detect { genomic, cdna }` → exons, introns, mapping quality.

### 14.3 Удаление интронов (Exon Fusion)

Кнопка «✂ introns» на CDS фрагменте с интронами. Система:
1. Разбивает CDS на экзоны
2. Каждый экзон → отдельный фрагмент на canvas
3. Overlap junctions между экзонами ПЕРЕПРЫГИВАЮТ интроны
4. Все экзоны амплифицируются с ОДНОГО геномного темплейта
5. Собирается overlap PCR → cDNA без интронов

---

## Часть XV. Дизайн-система

### 15.1 Цвета features (Okabe-Ito)

Дальтоник-совместимая палитра: CDS=#56B4E9 (голубой), promoter=#009E73 (зелёный), terminator=#D55E00 (красно-оранжевый), rep_origin=#E69F00, marker=#F0E442, signal_peptide=#CC79A7. Нуклеотиды: A=зелёный, T=красный, G=золотой, C=синий (стандарт Sanger).

### 15.2 Шрифты

JetBrains Mono для ДНК последовательностей (лигатуры отключены). Inter для интерфейса. Оба с хорошей кириллицей.

### 15.3 Русификация

Интерфейс на русском (кнопки, заголовки, предупреждения, подписи). Научная номенклатура на английском (имена генов, ферментов, плазмид, форматы файлов). Единицы: п.н. (bp), т.п.н. (kb), а.о. (aa), кДа (kDa).

